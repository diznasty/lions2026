# SCVAA Lions Rotation App

A single-file GitHub Pages app for the Lions 20-play game rotation.

## What it does
- Starts with the pre-planned 20-play rotation.
- Lets coaches mark no-shows before the game and rebuild the full rotation.
- Has a Live Game mode.
- Completed plays can be locked.
- If a player gets hurt/leaves, remove them and rebuild only the remaining plays.
- Keeps live offense, defense, and total rep counts.
- Every future lineup can still be manually edited.
- Can export the final game rotation to CSV or print/save as PDF.

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` to the root of the repository.
3. Open Repository Settings > Pages.
4. Choose "Deploy from a branch".
5. Select the `main` branch and `/ (root)`.
6. Save.
7. GitHub will provide the public Pages URL.

No build tools or server are required.
